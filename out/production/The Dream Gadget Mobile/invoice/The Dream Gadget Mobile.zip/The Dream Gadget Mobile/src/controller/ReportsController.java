package controller;

import DB.DbConnection;
import javafx.fxml.Initializable;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

public class ReportsController implements Initializable {
    public Label lblDailyIncome;
    public Label lblMonthlyIncome;
    public Label lblAnnualIncome;
    public javafx.scene.chart.LineChart LineChart;
    Date date;
    SimpleDateFormat sdf;
    static String todayIncome, thisMonthIncome, thisYerIncome;

/*    private void getIncome() {
        String year, month, day;
        date = new Date();
        sdf = new SimpleDateFormat("yyyy");
        year = sdf.format(date);
        sdf = new SimpleDateFormat("yyyy-MM");
        month = sdf.format(date);
        sdf = new SimpleDateFormat("yyyy-MM-dd");
        day = sdf.format(date);

        todayIncome = 0;
        thisMonthIncome = 0;
        thisYerIncome = 0;
        try {
            PreparedStatement preparedStatement = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM orders where odate  LIKE '" + year + "%'");
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                thisYerIncome += Double.parseDouble(resultSet.getString("cost"));
            }
            lblAnnualIncome.setText("" + thisYerIncome);

            preparedStatement = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM orders where odate  LIKE '" + month + "%'");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                thisMonthIncome += Double.parseDouble(resultSet.getString("cost"));
            }
            lblMonthlyIncome.setText("" + thisMonthIncome);

            preparedStatement = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM orders where odate = '" + day + "'");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                todayIncome += Double.parseDouble(resultSet.getString("cost"));
            }
            lblDailyIncome.setText("" + todayIncome);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/


    private void getIncome() {
        String year, month, day;
        date = new Date();
        sdf = new SimpleDateFormat("yyyy");
        year = sdf.format(date);
        sdf = new SimpleDateFormat("yyyy-MM");
        month = sdf.format(date);
        sdf = new SimpleDateFormat("yyyy-MM-dd");
        day = sdf.format(date);

        todayIncome = String.valueOf(0);
        thisMonthIncome = String.valueOf(0);
        thisYerIncome = String.valueOf(0);
        try {
            PreparedStatement preparedStatement = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM `orders` where odate LIKE '" + year + "%'");
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                thisYerIncome += resultSet.getString("cost");
            }
            lblAnnualIncome.setText("" + thisYerIncome);

            preparedStatement = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM `orders` where odate LIKE '" + month + "%'");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                thisMonthIncome += resultSet.getString("cost");
            }
            lblMonthlyIncome.setText("" + thisMonthIncome);

            preparedStatement = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM `orders` where odate= '" + day + "'");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                todayIncome += resultSet.getString("cost");
            }
            System.out.println(todayIncome);

            lblDailyIncome.setText("" + todayIncome);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public javafx.scene.chart.LineChart getLineChart() {
        return LineChart;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        LineChart.setTitle("INCOME");

        XYChart.Series series=new XYChart.Series();
        series.setName("Sales");

        series.getData().add(new XYChart.Data("Jan",23));
        series.getData().add(new XYChart.Data("Feb",14));
        series.getData().add(new XYChart.Data("March",15));
        series.getData().add(new XYChart.Data("April",24));
        series.getData().add(new XYChart.Data("May",34));
        series.getData().add(new XYChart.Data("Jun",36));
        series.getData().add(new XYChart.Data("Jul",22));
        series.getData().add(new XYChart.Data("Aug",45));
        series.getData().add(new XYChart.Data("Sep",43));
        series.getData().add(new XYChart.Data("Oct",17));
        series.getData().add(new XYChart.Data("Nov",29));
        series.getData().add(new XYChart.Data("Dec",25));

        LineChart.getData().add(series);


        getIncome();
    }
}
