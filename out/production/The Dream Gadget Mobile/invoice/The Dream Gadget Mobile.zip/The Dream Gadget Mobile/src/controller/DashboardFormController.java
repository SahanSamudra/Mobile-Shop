package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

public class DashboardFormController {

    public AnchorPane DashboardFormContext;
    public AnchorPane btnAllContext;
    public AnchorPane AllContext;


    public void initialize() throws IOException {
        home();
    }



    public void home() throws IOException {
        URL resource = getClass().getResource("../views/DisplayDashboard.fxml");
        assert resource != null;
        Parent load = FXMLLoader.load(resource);
        AllContext.getChildren().clear();
        AllContext.getChildren().add(load);


    }

    public void btnCustomers(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../views/Customer.fxml");
        assert resource != null;
        Parent load = FXMLLoader.load(resource);
        AllContext.getChildren().clear();
        AllContext.getChildren().add(load);
    }

    public void btnAddItems(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../views/AddItems.fxml");
        assert resource != null;
        Parent load = FXMLLoader.load(resource);
        AllContext.getChildren().clear();
        AllContext.getChildren().add(load);
    }

    public void btnReports(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../views/Reports.fxml");
        assert resource != null;
        Parent load = FXMLLoader.load(resource);
        AllContext.getChildren().clear();
        AllContext.getChildren().add(load);
    }

    public void btnRepair(ActionEvent actionEvent) throws IOException {

        URL resource = getClass().getResource("../views/Repair.fxml");
        assert resource != null;
        Parent load = FXMLLoader.load(resource);
        AllContext.getChildren().clear();
        AllContext.getChildren().add(load);
    }

    public void btnReturnItem(ActionEvent actionEvent) throws IOException {

        URL resource = getClass().getResource("../views/ReturnItem.fxml");
        assert resource != null;
        Parent load = FXMLLoader.load(resource);
        AllContext.getChildren().clear();
        AllContext.getChildren().add(load);
    }

    public void btnBilling(ActionEvent actionEvent) throws IOException {

        URL resource = getClass().getResource("../views/Billing.fxml");
        assert resource != null;
        Parent load = FXMLLoader.load(resource);
        AllContext.getChildren().clear();
        AllContext.getChildren().add(load);
    }

    public void btnPurchase(ActionEvent actionEvent) throws IOException {


    }

    public void btnLogOut(ActionEvent actionEvent) throws IOException {
        Stage window = (Stage) DashboardFormContext.getScene().getWindow();
        window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../views/LogInForm.fxml"))));
        window.centerOnScreen();
    }

    public void btnDashBoard(ActionEvent actionEvent) throws IOException {

        home();
    }

    public void btnSupplier(ActionEvent actionEvent) throws IOException {

        URL resource = getClass().getResource("../views/Supplier.fxml");
        assert resource != null;
        Parent load = FXMLLoader.load(resource);
        AllContext.getChildren().clear();
        AllContext.getChildren().add(load);
    }

    public void btnOrders(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../views/Orders.fxml");
        assert resource != null;
        Parent load = FXMLLoader.load(resource);
        AllContext.getChildren().clear();
        AllContext.getChildren().add(load);
    }

/*    public void btnDashboard(ActionEvent actionEvent) throws IOException {

        home();
    }*/



  /*  public void btnLogOut(ActionEvent actionEvent) throws IOException {
        Stage window = (Stage) DashboardFormContext.getScene().getWindow();
        window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../views/LogInForm.fxml"))));
        window.centerOnScreen();
    }
*/
/*    public void btnLogOut(ActionEvent actionEvent) throws IOException {
        Stage window = (Stage) DashboardFormContext.getScene().getWindow();
        window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../views/LogInForm.fxml"))));
        window.centerOnScreen();


    }*/
}
   /*     URL resource = getClass().getResource("../view/DashBoard.fxml");
        assert resource != null;
        Parent load= FXMLLoader.load(resource);
        LoginFormContext.getChildren().clear();
        LoginFormContext.getChildren().add(load);*/